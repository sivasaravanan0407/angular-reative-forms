import { Component } from '@angular/core';
import { FormGroup, FormControl,FormBuilder, Validators,FormArray   } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'reactForm';
  profileForm = this.fb.group({
    firstName: [null,[Validators.required,Validators.pattern('^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$')]],
    lastName: [null,[Validators.required,Validators.pattern('^[a-zA-Z0-9]+([._]?[a-zA-Z0-9]+)*$')]],
    
  });
  constructor(private fb: FormBuilder) { }

  get firstName(){
    const temp = <FormGroup>this.profileForm.controls.firstName;
    return temp;  
  }
  get lastName(){
    const temp = <FormGroup>this.profileForm.controls.lastName;
    return temp;  
  }

  myForm: FormGroup;
  arr: FormArray;


  ngOnInit() {
    this.myForm = this.fb.group({
      arr: this.fb.array([this.createItem()])
    })
  }

  createItem() {
    return this.fb.group({
      name: [''],
    })
  }

  addItem() {
    this.arr = this.myForm.get('arr') as FormArray;
    this.arr.push(this.createItem());
  }



  onSumbit(){
    if(this.profileForm.valid === true){
      console.log(this.profileForm);
    } 
  }
}
